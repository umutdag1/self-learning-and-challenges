module.exports = function circleArea(radius) {
    console.log(Math.PI * radius * radius)
}

module.exports = function circleCircumference(radius) {
    console.log(2 * Math.PI * radius)
}
