const circle = require('./circle.js');


circle.circleArea(5);
circle.circleCircumference(5);