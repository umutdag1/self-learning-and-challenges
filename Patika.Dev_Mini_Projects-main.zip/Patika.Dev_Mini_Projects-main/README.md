# Patika.Dev_Mini_Projects
Patika.dev mini projects
